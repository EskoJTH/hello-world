﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BlueBeard
{
    class stuff
    {
        public static void SpaceText()
        {
            int emptyRows = 3;
            for (int i=0; i<emptyRows;i++) Console.WriteLine(".");
        }
    }
}
